package com.example.ClassesOrderDemo;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;


@Order(1)
public class UserServiceTest {


    @BeforeAll
    static void setup() {
        System.out.println("Test methods related to User");
    }

    @Test
    void testCreateUser_whenFirstNameIsMissing_throwsUserServiceException() {
    }

    //If i used Integration testing i want UserServiceTest need to execute
    // first but now OrderServiceTest and ProductServiceTest
//Executing,Becoz Product cannot be Ordered without existingUser account
    //The order i want to run the tests is
//    1.UserServiceTest
 //    2.ProductServiceTest
//    3.OrderServiceTest
    //In previous lessons we have used the method Order to configure
    //excution order of method or class
    //Junit allows us to configure Properties for Entire propertie globally
    //without using @MethodOrder annotation
    //we need to create a resource folder in test
}
