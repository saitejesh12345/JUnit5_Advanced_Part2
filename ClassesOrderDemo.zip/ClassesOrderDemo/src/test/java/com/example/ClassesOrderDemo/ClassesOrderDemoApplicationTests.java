//package com.example.ClassesOrderDemo;
//
//import org.junit.jupiter.api.Test;
//import org.springframework.boot.test.context.SpringBootTest;
//
//@SpringBootTest
//class ClassesOrderDemoApplicationTests {
//
//	@Test
//	void contextLoads() {
//	}
//
//}
